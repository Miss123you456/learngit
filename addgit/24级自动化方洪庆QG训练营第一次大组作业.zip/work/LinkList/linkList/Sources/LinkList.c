#include<stdio.h>
#include<stdlib.h>
#include"LinkList.h"

Status InitList(LinkedList* L)
{

    *L = (LinkedList)malloc(sizeof(LNode));

    if (*L == NULL)
    {
        return ERROR;
    }
    (*L)->next = NULL;
    return SUCCESS;
}
void DestroyList(LinkedList* L) {

    LinkedList p = *L;
    while (p != NULL)
    {
        LinkedList temp = p->next;
        free(p);
        p = temp;
    }
    *L = NULL;
}
Status InsertList(LNode* p, LNode* q)
{
    if (p == NULL || q == NULL) return ERROR;

    q->next = p->next;
    p->next = q;
    return SUCCESS;
}
Status DeleteList(LNode* p, ElemType* e)
{

    if (p == NULL || p->next == NULL) return ERROR;

    LNode* temp = p->next;

    *e = temp->data;
    p->next = temp->next;
    free(temp);
    return SUCCESS;
}
void TraverseList(LinkedList L, void (*visit)(ElemType e))
{
    LNode* p = L->next;

    while (p != NULL)
    {
        visit(p->data);
        p = p->next;
    }
}
Status SearchList(LinkedList L, ElemType e)
{

    LNode* p = L->next;

    while (p != NULL)
    {
        if (p->data == e)
        {
            return SUCCESS;
        }
        p = p->next;
    }
    return ERROR;
}
int main()
{
    LinkedList* L;
    LNode* p;
    LNode* q;
    ElemType* e;
    printf("请输入数字");
    printf("1.初始化链表");
    printf("2.清空链表");
    printf("3.插入节点");
    printf("4.删除节点");
    printf("5.遍历链表");
    printf("6.寻找节点");
    int choice;
    scanf("%d", &choice);
    switch (choice)
    {
    case(1):
    {
        InitList(L);
        break;
    }
    case(2):
    {
        DestroyList(L);
        break;
    }
    case(3):
    {
        InsertList(p, q);
        break;
    }
    case(4):
    {
        DeleteList(p, e);
        break;
    }
    case(5):
    {
        TraverseList(L, e);
        break;
    }
    case(6):
    {
        SearchList(L, e);
        break;
    }
    }
    return 0;

}