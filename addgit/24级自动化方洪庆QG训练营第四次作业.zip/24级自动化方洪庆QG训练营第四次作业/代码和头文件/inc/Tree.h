//
//

#include<stdio.h>
#include<stdlib.h>
#ifndef BINARYSORTTREE_BINARY_SORT_TREE_H
#define BINARYSORTTREE_BINARY_SORT_TREE_H

#define true 1
#define false 0
#define succeed 1
#define failed 0
#define Status int
#define MAX_STACK_SIZE 100
#define MAX_QUEUE_SIZE 100



typedef int ElemType;

typedef struct Node{
    ElemType value;
    struct Node *left, *right;
}Node, *NodePtr;

typedef struct BinarySortTree{
    NodePtr root;
} BinarySortTree, *BinarySortTreePtr;
// 辅助栈结构用于非递归遍历
typedef struct StackNode {
    NodePtr data;
    struct StackNode *next;
} StackNode, *Stack;

void push(Stack *s, NodePtr node) {
    StackNode *newNode = (StackNode *)malloc(sizeof(StackNode));
    newNode->data = node;
    newNode->next = *s;
    *s = newNode;
}

NodePtr pop(Stack *s) {
    if (*s == NULL) return NULL;
    StackNode *temp = *s;
    NodePtr data = temp->data;
    *s = (*s)->next;
    free(temp);
    return data;
}

int isEmpty(Stack s) {
    return s == NULL;
}

/**
 * BST initialize
 * @param BinarySortTreePtr BST
 * @return is complete
 */
//Status BST_init(BinarySortTreePtr);
Status BST_init(BinarySortTreePtr bst) {
    if (bst == NULL) {
        return failed; // 如果传入指针为空，返回错误状态
    }
    bst->root = NULL; // 将根节点指针设为NULL
    return succeed; // 返回成功状态
}
/**
 * BST insert
 * @param BinarySortTreePtr BST
 * @param ElemType value to insert
 * @return is successful
 */
//Status BST_insert(BinarySortTreePtr, ElemType);

Status BST_insert(BinarySortTreePtr bst, ElemType value) 
{
    // 检查BST指针有效性
    if (bst == NULL) {
        return failed;
    }

    // 创建新节点并初始化
    NodePtr newNode = (NodePtr)malloc(sizeof(Node));
    if (!newNode) {
        return failed; // 内存分配失败
    }
    newNode->value = value;
    newNode->left = newNode->right = NULL;

    // 处理空树情况
    if (bst->root == NULL) {
        bst->root = newNode;
        return succeed;
    }

    NodePtr current = bst->root;
    while (current) {
        if (value < current->value) { // 插入左子树
            if (current->left == NULL) {
                current->left = newNode;
                return succeed;
            }
            current = current->left;
        } else if (value > current->value) { // 插入右子树
            if (current->right == NULL) {
                current->right = newNode;
                return succeed;
            }
            current = current->right;
        } else { // 值已存在，禁止重复
            free(newNode);
            return failed;
        }
    }
}
/**
 * BST delete
 * @param BinarySortTreePtr BST
 * @param ElemType the value for Node which will be deleted
 * @return is successful
 */
Status BST_delete(BinarySortTreePtr, ElemType);

Status BST_delete(BinarySortTreePtr bst, ElemType e) {
    if (bst == NULL || bst->root == NULL) return false;

    NodePtr parent = NULL, current = bst->root;
    while (current != NULL && current->value != e) {
        parent = current;
        if (e < current->value) current = current->left;
        else current = current->right;
    }
    if (current == NULL) return false;

    if (current->left == NULL || current->right == NULL) {
        NodePtr child = current->left ? current->left : current->right;
        if (!parent) bst->root = child;
        else {
            if (parent->left == current) parent->left = child;
            else parent->right = child;
        }
        free(current);
    } else {
        NodePtr minParent = current;
        NodePtr minNode = current->right;
        while (minNode->left) {
            minParent = minNode;
            minNode = minNode->left;
        }
        current->value = minNode->value;
        if (minParent->left == minNode) minParent->left = minNode->right;
        else minParent->right = minNode->right;
        free(minNode);
    }
    return true;
}

/**
 * BST search
 * @param BinarySortTreePtr BST
 * @param ElemType the value to search
 * @return is exist
 */
Status BST_search(BinarySortTreePtr, ElemType);
Status BST_search(BinarySortTreePtr bst, ElemType e) {
    if (bst == NULL) return false;
    NodePtr current = bst->root;
    while (current != NULL) {
        if (e == current->value) return true;
        else if (e < current->value) current = current->left;
        else current = current->right;
    }
    return false;
}

/**
 * BST preorder traversal without recursion
 * @param BinarySortTreePtr BST
 * @param (*visit) callback
 * @return is successful
 */
Status BST_preorderI(BinarySortTreePtr, void (*visit)(NodePtr));
Status BST_preorderI(BinarySortTreePtr bst, void (*visit)(NodePtr)) {
    if (bst == NULL || bst->root == NULL) return false;
    Stack s = NULL;
    push(&s, bst->root);
    while (!isEmpty(s)) {
        NodePtr node = pop(&s);
        visit(node);
        if (node->right) push(&s, node->right);
        if (node->left) push(&s, node->left);
    }
    return true;
}
/**
 * BST preorder traversal with recursion
 * @param BinarySortTreePtr BST
 * @param (*visit) callback
 * @return is successful
 */
static void preorderRHelper(NodePtr node, void (*visit)(NodePtr)) {
    if (!node) return;
    visit(node);
    preorderRHelper(node->left, visit);
    preorderRHelper(node->right, visit);
}

Status BST_preorderR(BinarySortTreePtr, void (*visit)(NodePtr));

Status BST_preorderR(BinarySortTreePtr bst, void (*visit)(NodePtr)) {
    if (bst == NULL) return false;
    preorderRHelper(bst->root, visit);
    return true;
}

/**
 * BST inorder traversal without recursion
 * @param BinarySortTreePtr BST
 * @param (*visit) callback
 * @return is successful
 */
Status BST_inorderI(BinarySortTreePtr, void (*visit)(NodePtr));

Status BST_inorderI(BinarySortTreePtr bst, void (*visit)(NodePtr)) {
    if (bst == NULL || bst->root == NULL) return false;
    Stack s = NULL;
    NodePtr current = bst->root;
    while (current != NULL || !isEmpty(s)) {
        while (current != NULL) {
            push(&s, current);
            current = current->left;
        }
        current = pop(&s);
        visit(current);
        current = current->right;
    }
    return true;
}

/**
 * BST inorder traversal with recursion
 * @param BinarySortTreePtr BST
 * @param (*visit) callback
 * @return is successful
 */
static void inorderRHelper(NodePtr node, void (*visit)(NodePtr)) {
    if (!node) return;
    inorderRHelper(node->left, visit);
    visit(node);
    inorderRHelper(node->right, visit);
}
Status BST_inorderR(BinarySortTreePtr, void (*visit)(NodePtr));


Status BST_inorderR(BinarySortTreePtr bst, void (*visit)(NodePtr)) {
    if (bst == NULL) return false;
    inorderRHelper(bst->root, visit);
    return true;
}
/**
 * BST preorder traversal without recursion
 * @param BinarySortTreePtr BST
 * @param (*visit) callback
 * @return is successful
 */
Status BST_postorderI(BinarySortTreePtr, void (*visit)(NodePtr));

Status BST_postorderI(BinarySortTreePtr bst, void (*visit)(NodePtr)) {
    if (bst == NULL || bst->root == NULL) return false;
    Stack s1 = NULL, s2 = NULL;
    push(&s1, bst->root);
    while (!isEmpty(s1)) {
        NodePtr node = pop(&s1);
        push(&s2, node);
        if (node->left) push(&s1, node->left);
        if (node->right) push(&s1, node->right);
    }
    while (!isEmpty(s2)) visit(pop(&s2));
    return true;
}

/**
 * BST postorder traversal with recursion
 * @param BinarySortTreePtr BST
 * @param (*visit) callback
 * @return is successful
 */
static void postorderRHelper(NodePtr node, void (*visit)(NodePtr)) {
    if (!node) return;
    postorderRHelper(node->left, visit);
    postorderRHelper(node->right, visit);
    visit(node);
}

Status BST_postorderR(BinarySortTreePtr, void (*visit)(NodePtr));


Status BST_postorderR(BinarySortTreePtr bst, void (*visit)(NodePtr)) {
    if (bst == NULL) return false;
    postorderRHelper(bst->root, visit);
    return true;
}

/**
 * BST level order traversal
 * @param BinarySortTreePtr BST
 * @param (*visit) callback
 * @return is successful
 */
Status BST_levelOrder(BinarySortTreePtr, void (*visit)(NodePtr));

Status BST_levelOrder(BinarySortTreePtr bst, void (*visit)(NodePtr)) {
    if (bst == NULL || bst->root == NULL) return false;
    NodePtr queue[MAX_QUEUE_SIZE];
    int front = 0, rear = 0;
    queue[rear++] = bst->root;
    while (front < rear) {
        NodePtr node = queue[front++];
        visit(node);
        if (node->left) queue[rear++] = node->left;
        if (node->right) queue[rear++] = node->right;
        if (rear >= MAX_QUEUE_SIZE) return false; // 简单处理溢出
    }
    return true;
}

#endif //BINARYSORTTREE_BINARY_SORT_TREE_H
