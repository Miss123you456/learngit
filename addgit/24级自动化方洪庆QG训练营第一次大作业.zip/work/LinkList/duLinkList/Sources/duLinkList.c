﻿#include<stdio.h>
#include<stdlib.h>
#include"duLinkedList.h"

Status InitList_DuL(DuLinkedList* L)
{
    *L = (DuLNode*)malloc(sizeof(DuLNode));
    if (*L == NULL)
    {
        return ERROR;
    }
    else
    {
        //初始化前后指�?
        (*L)->prior = *L;
        (*L)->next = *L;
        return SUCCESS;
    }
}

void DestroyList_DuL(DuLinkedList* L) {
    if (*L == NULL)
    {
        return;
    }
    DuLNode(*pCurrent) = (*L)->next;
    while (pCurrent != *L)
    {
        DuLNode(*temp) = pCurrent;
        pCurrent = pCurrent->next;
        free(temp);
    }
    free(*L);
    *L = NULL;
}
Status InsertBeforeList_DuL(DuLNode* p, DuLNode* q)
{
    if (q == NULL || p == NULL)
    {
        return ERROR;
    }
    q->prior = p->prior;
    q->next = p;
    if (p->next == NULL)
    {
        p = q;
    }
    p->prior = q;
    return SUCCESS;
}
Status InsertAfterList_DuL(DuLNode* p, DuLNode* q)
{
    if (q == NULL || p == NULL)
    {
        return ERROR;
    }
    q->next = p->next;
    q->prior = p;
    if (p->next == NULL)
    {
        p = q;
    }
    p->next = q;
    return SUCCESS;
}

Status DeleteList_DuL(DuLNode* p, ElemType* e) {
    if (p == NULL || p->next == p)
    {
        return ERROR;
    }
    DuLNode(*s) = p->next;
    *e = s->data;
    p->next = s->next;
    s->next->prior = p;
    free(s);
    return SUCCESS;
}

void TraverseList_DuL(DuLinkedList L, void (*visit)(ElemType e)) {
    if (L == NULL)
    {
        return;
    }

    DuLNode* pCurrent = L->next;
    while (pCurrent != L)
    {
        visit(pCurrent->data);
        pCurrent = pCurrent->next;
    }
}

int main()
{

    printf("请输入数字");
    printf("1.初始化链表");
    printf("2.在前面插入节点");
    printf("3.在后面插入节点");
    printf("4.删除节点");
    printf("5.遍历链表");
    printf("6.清空连表");
    int choice;
    scanf("%d", choice);
    DuLinkedList* L;
    DuLNode* p;
    DuLNode* q;
    ElemType* e;

    switch (choice)
    {
    case(1):
    {
        InitList_DuL(L);
    }
    case(2):
    {
        InsertBeforeList_DuL(p, q);
    }
    case(3):
    {
        InsertAfterList_DuL(p, q);
    }
    case(4):
    {
        DeleteList_DuL(p, e);
    }
    case(5):
    {
        TraverseList_DuL(L, e);
    }
    case(6):
    {
        DestroyList_DuL(L);
    }

    }
}