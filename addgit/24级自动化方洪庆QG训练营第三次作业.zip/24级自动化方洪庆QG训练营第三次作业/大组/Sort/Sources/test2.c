#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>  
#include "sort.h" 
// �����������ģ��
void generate_random_array(int *arr, int n) {
    for (int i = 0; i < n; i++) {
        // ��϶��rand()����Ի�ø������ֵ��Χ
        arr[i] = (rand() << 16) | rand();
    }
}

// ��֤�����Ƿ�����
int sorted(int arr[], int len) 
{
    for (int i = 0; i < len - 1; i++)
     {
        if (arr[i] > arr[i + 1]) return 0;
    }
    return 1;
}
int main()
{
    const int data_size=100;
    const int num_sorts=100000;

    int *template=(int *)malloc(data_size*sizeof(int));
    int *temp=(int *)malloc(data_size*sizeof(int));
    if(template==NULL||temp==NULL)
    {
        printf("�ڴ����ʧ��");
        free(template);
        free(temp);
        exit(EXIT_FAILURE);
    }

    srand(time(NULL));
    generate_random_array(template,data_size);
    memcpy(temp,template,data_size*sizeof(int));
    clock_t start=clock();
    for(int i=0;i<num_sorts;i++)
    {
    
    QuickSort_Recursion(temp,0,data_size-1);
    }
    clock_t end=clock();
    
    if(sorted(temp,data_size)==0)
    {
        printf("�������");
        free(temp);
        free(template);
        exit(EXIT_FAILURE);
    }
    double total_time=(double)(end-start)/CLOCKS_PER_SEC;

    double avg_time=total_time/num_sorts;

    printf("%.5f\n",total_time);
    printf("%.7f",avg_time);
    system("pause");
}