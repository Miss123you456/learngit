#include <REGX52.H>

void Timer0_Init(void)		
{
	TMOD |= 0x01;			
	TL0 = 0x18;				
	TH0 = 0xFC;				
	ET0=1;
	EA=1;
	TR0 = 1;				
}