#include <REGX52.H>

void UART_Init()
{
	SCON=0x50;
	TMOD=0x20;
	TH1=0xFD;
	TL1=0xFD;
	TR1=1;
	ES=1;
	EA=1;
}
