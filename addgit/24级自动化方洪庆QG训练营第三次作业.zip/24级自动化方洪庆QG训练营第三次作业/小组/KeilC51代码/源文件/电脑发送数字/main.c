#include <REGX52.H>
#include "Delay.h"
#include "UART.h"



void main()
{
	UART_Init();
	while(1)
	{
	UART_SendString("Hello World!\r\n");
	Delay(1000);
	}
}