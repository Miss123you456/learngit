#include <REGX52.H>
#include "Timer0.h"

unsigned int T0Count=0;

void main()	
{  	
	
	Timer0_Init();
	P2=0xFE;
	while(1);
}
void Timer0_Routine() interrupt 1
{	
	TL0 = 0x18;
	TH0 = 0xFC;			
	T0Count++;
	if(T0Count>=1000)
	{
		T0Count=0;
		P2=~P2;
	}
}
