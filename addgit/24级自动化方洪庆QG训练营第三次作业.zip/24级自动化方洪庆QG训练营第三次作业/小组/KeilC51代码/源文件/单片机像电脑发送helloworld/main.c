#include <REGX52.H>
#include "UART.h"

unsigned char received;
unsigned char code seg[]={0x3F,0x06,0x5B,0x4F,0x66,0x6D,0x7D,0x07,0x7F,0x6F};



void main()
{
	UART_Init();
	P1=0xFF;
	P2=0x00;
	
	while(1);
}

void UART_Routine()  interrupt 4
{
	if(RI)
	{
		RI=0;
		received=SBUF;
		if(received>='0'&&received<='9')
		{
			P2=seg[received-'0'];
			P1=0xFE;
		}
	}
	
}