#include <reg51.h>
#include <intrins.h> 
#include "Timer0.h"
#define LED_PORT P2 
unsigned int T0Count=0;
unsigned char led_pattern=0xFE;

void main()	
{  	
	Timer0_Init();
	LED_PORT=led_pattern;
	while(1);
}
void Timer0_Routine() interrupt 1
{	
	TL0 = 0x18;
	TH0 = 0xFC;			
	T0Count++;
	if(T0Count>=1000)
	{
		T0Count=0;
		led_pattern=_crol_(led_pattern,1);
		LED_PORT=led_pattern;
	}
}

