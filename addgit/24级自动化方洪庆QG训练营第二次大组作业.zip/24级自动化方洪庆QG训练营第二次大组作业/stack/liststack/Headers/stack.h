#include<stdio.h>
#include<stdlib.h>
typedef struct LNode
{
    int data;
    struct LNode*next;
}LNode,*LinkList;
typedef struct  Stack
{
    LinkList TopStack;//栈顶标记
    int size;
}Stack,*LinkStack;
struct Stack*myStack_Init()
{
    LinkStack mystack=(LinkStack)malloc(sizeof(Stack));
    mystack->TopStack=NULL;
    mystack->size=0;
    return mystack;
}
/*入栈*/
void push(LinkStack myStack,int data)
{
    //创建新节点
    LNode* newnode=(LNode*)malloc(sizeof(LNode));
    newnode->data=data;
    newnode->next=NULL;
    
    //链表表头插入----入栈
    newnode->next=myStack->TopStack;
    myStack->TopStack=newnode;
    myStack->size++;
}
/*获取栈顶数据*/
int Top(LinkStack mystack)
{
    if(mystack->size==0)
    {
        printf("error");
    }
    else
    {
       printf("%d", mystack->TopStack->data);
    }
}
//出栈
void pop(LinkStack myStack)
{
    if(myStack->size==0)
    {
        return ;
    }
    else
    {
        LinkList nodenext=myStack->TopStack->next;
        free(myStack->TopStack);
        myStack->TopStack=nodenext;
        myStack->size--;
    }
}