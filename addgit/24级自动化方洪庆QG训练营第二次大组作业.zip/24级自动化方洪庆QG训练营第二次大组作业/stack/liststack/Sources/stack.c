#include"stack.h"
void test()
{
    LinkStack myStack=myStack_Init();
    push(myStack,1);
    push(myStack,7);
    push(myStack,3);
    push(myStack,9);
    Top(myStack);
    pop(myStack);
    Top(myStack);
}
int main()
{
    test();
    return 0;
}