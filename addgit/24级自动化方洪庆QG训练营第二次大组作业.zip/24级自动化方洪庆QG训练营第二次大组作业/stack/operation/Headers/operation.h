#include<stdio.h>
#include<stdlib.h>
#include<stdbool.h>
const char oper[7]={ '+' , '-' , '*' , '/' , '(' , ')' , '#' };//四则运算的符号
typedef struct LNode
{
    int data;
    char ch;
    struct LNode*next;
}LNode,*LinkList;
typedef struct  Stack
{
    LinkList TopStack;//栈顶标记
    int size;
}Stack,*LinkStack;
//初始化栈
struct Stack*myStack_Init()
{
    LinkStack myStack=(LinkStack)malloc(sizeof(Stack));
    myStack->TopStack=NULL;
    myStack->size=0;
    return myStack;
}
/*数字入栈*/
void pushnum(LinkStack myStack,int data)
{
    //创建新节点
    LinkList newnode=(LinkList)malloc(sizeof(LNode));
    newnode->data=data;
    newnode->ch='\0';
    newnode->next=NULL;
    
    //链表表头插入----入栈
    newnode->next=myStack->TopStack;
    myStack->TopStack=newnode;
    myStack->size++;
}
//字符入栈
void pushchar(LinkStack myStack,char ch)
{
    LinkList newnode=(LinkList)malloc(sizeof(LNode));
    newnode->ch=ch;
    newnode->data=0;
    newnode->next=NULL;
    //链表表头插入
    newnode->next=myStack->TopStack;
    myStack->TopStack=newnode;
    myStack->size++;
}
/*获取栈顶数据*/
//数字栈栈顶数字
int GetTopNum(LinkStack mystack)
{
    if(mystack->size==0)
    {
        printf("栈为空") ;
    }
    else
    {
        return mystack->TopStack->data;
    }
}
//获取符号栈顶数据
char GetTopchar(LinkStack mystack)
{
    if(mystack->size==0)
    {
        printf("栈为空") ;
    }
    else
    {
        return mystack->TopStack->ch;
    }
}
//出栈
void poptop(LinkStack myStack)
{
    if(myStack->size==0)
    {
        return ;
    }
    else
    {
        LNode* nodenext=myStack->TopStack->next;
        free(myStack->TopStack);
        myStack->TopStack=nodenext;
        myStack->size--;
    }
}
/*实现四则运算*/
//先找运算符和数字
//是运算符返回true  是数字返回false
bool In(char ch)
{
    for(int i=0;i<7;i++)
    {
        if(ch==oper[i])
        {
            return true;
        }
    } 
    return false;
}
//给运算符返回一个值用于二维数组
int getIndex(char ch)
{
    switch(ch)
    {
        case '+':return 0;
        case '-':return 1;
        case '*':return 2;
        case '/':return 3;
        case '(':return 4;
        case ')':return 5;
        case '#':return 6;
        default:return -1;
    }
}
//判断运算符优先级
char Precede(char theta1,char theta2)
{
    int i = getIndex(theta1);
    int j = getIndex(theta2);
    char precedence[7][7] = {
        {'>','>','<','<','<','>','>'},  
        {'>','>','<','<','<','>','>'},  
        {'>','>','>','>','<','>','>'},  
        {'>','>','>','>','<','>','>'},  
        {'<','<','<','<','<','=',' '},  
        {'>','>','>','>',' ','>','>'},  
        {'<','<','<','<','<',' ','='}   
    };
    return precedence[i][j];
}
//运算符的使用
int Operate(int a, char ch, int b) {

    switch(ch) {
    
    case '+': return a + b;
    
    case '-': return a - b;
    
    case '*': return a * b;
    
    case '/': return a / b;

    default:return 0;
    }
}
//跳过空格和换行
char getNextChar()
{
    char ch;
    do
    {
        scanf("%c",&ch);
    } while (ch==' '||ch=='\n');
    
}
//表达式求值
int EvaluateExpression()
{

    char ch,theta;
    LinkStack StackChar=myStack_Init();//符号栈
    LinkStack StackNum=myStack_Init();//数字栈
    pushchar(StackChar,'#');
    ch=getNextChar();

    while(ch != '#' || GetTopchar(StackChar) != '#')//当字符为'#'或者字符栈里栈顶为'#'退出循环
    {
        if(!In(ch))
        {
            int num=ch-'0';
            ch=getNextChar();
            while(!In(ch))
            {
                num=num*10+(ch-'0');//用于多位数
                ch=getNextChar();
            }
            pushnum(StackNum,num);
        }
        else
        {
            switch(Precede(GetTopchar(StackChar),ch))//判断栈顶元素和入栈ch的优先级
            {
                case('<'):
                {
                    pushchar(StackChar,ch);//用栈顶元素和入栈元素比较,栈顶元素在前,小于则说明可以入栈
                    ch =getNextChar();
                    break;
                }
                case('>'):
                {
                   int a=GetTopNum(StackNum);
                   poptop(StackNum);
                   int b=GetTopNum(StackNum);
                   poptop(StackNum);
                   theta=GetTopchar(StackChar);
                   poptop(StackChar);
                   pushnum(StackNum,Operate(b,theta,a));
                    break;
                }
                case('='):
                {
                    poptop(StackChar);
                    ch=getNextChar();
                    break;
                }
            }
        }
    }
    int res=GetTopNum(StackNum);
    poptop(StackNum);
    return res;
}