#include<stdio.h>
#include"operation.h"
void test()
{
    LinkStack myStack=myStack_Init();
    printf("enter expression ending with #:");
    int res=EvaluateExpression();
    printf("%d",res);
    
}
int main()
{   
    test();
    return 0;
}